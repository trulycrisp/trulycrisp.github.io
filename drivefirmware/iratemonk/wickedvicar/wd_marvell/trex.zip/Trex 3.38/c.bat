COPY c:\west\CRACK\ENGVSC.CLQ c:\west /Y
COPY c:\west\CRACK\APPKEY.EXE c:\west /Y
COPY c:\west\CRACK\TREX.EXE c:\west /Y
date:01-07-2009
trexlite -z -b8192 cosoc.trx
